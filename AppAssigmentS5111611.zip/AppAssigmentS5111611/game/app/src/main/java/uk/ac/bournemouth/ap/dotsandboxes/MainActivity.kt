package uk.ac.bournemouth.ap.dotsandboxes

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlin.properties.Delegates


var choice :Int?= 0

class MainActivity : AppCompatActivity() {

//    Declaring 'buttonGoToGame' as type 'Button'.
    private lateinit var buttonGoToGame: Button
    private lateinit var buttonCompvPl: Button
    private lateinit var buttonPlvPl: Button
    private lateinit var buttonCompvComp: Button






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        Setting 'buttonGoToGame' as the id of the button used in the XML.
        buttonGoToGame = findViewById(R.id.btnGetName)
        buttonCompvPl = findViewById(R.id.PlaVSComp)
        buttonPlvPl = findViewById(R.id.PlaVsPla)



//        Created a listener to allow the application to capture when a user clicks.
        buttonCompvPl.setOnClickListener {
            choice=1


        }
        buttonPlvPl.setOnClickListener {
            choice=2


        }


        buttonGoToGame.setOnClickListener {
            val intent = Intent(this, GameActivity::class.java)
            intent.putExtra("GameChoice",choice.toString())
            startActivity(intent)


        }
    }
}