package uk.ac.bournemouth.ap.dotsandboxes


import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import org.example.student.dotsboxgame.Computer
import org.example.student.dotsboxgame.StudentDotsBoxGame
import uk.ac.bournemouth.ap.dotsandboxeslib.HumanPlayer
import uk.ac.bournemouth.ap.dotsandboxeslib.Player
import kotlin.IllegalArgumentException
import kotlin.math.roundToInt
//canvas and paint tutorial https://www.youtube.com/watch?v=gl6cvzS6-UI
//on touch tutorial https://www.youtube.com/watch?v=QBGokkznlOk and official kotlin documentation https://developer.android.com/training/graphics/opengl/touch

class GameView: View {
    constructor(
        context: Context?
               ) : super(context)

    constructor(
        context: Context?, attrs: AttributeSet?
               ) : super(context, attrs)

    constructor(
        context: Context?, attrs: AttributeSet?, defStyleAttr: Int
               ) : super(context, attrs, defStyleAttr)

    private val colCount = 8
    private val rowCount = 8



    private val choice2= choice
    // picks what game to create depending on choice
   fun startGame(choice:Int?):List<Player>{
       val players:List<Player>
       if(choice==1) {
           players = listOf(HumanPlayer(), Computer())
       }else {
           players=listOf(HumanPlayer(), HumanPlayer())
       }
       return players
   }

    // creates game instance depending on choice before
    var Game:StudentDotsBoxGame = StudentDotsBoxGame(colCount,rowCount,startGame(choice2))

    // different paint styles
    private var mNoPlayerPaint: Paint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.BLACK
        strokeWidth = 30f
        isAntiAlias = true
        strokeCap = Paint.Cap.ROUND
    }
    private var PaintLine:Paint = Paint().apply{

        color = Color.LTGRAY
        strokeWidth = 10f
        strokeCap = Paint.Cap.SQUARE

    }
    private var PaintLine1:Paint = Paint().apply{

        color = Color.BLUE
        strokeWidth = 10f
        strokeCap = Paint.Cap.SQUARE

    }
    private var text:Paint = Paint().apply{
        style = Paint.Style.FILL
        color = Color.BLACK
        strokeWidth = 40f
        strokeCap = Paint.Cap.SQUARE
        textSize = 100f

    }
    private var box: Paint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.GREEN
        strokeWidth = 100f


    }

    private var box1: Paint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.RED
        strokeWidth = 100f


    }
    private var block: Paint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.WHITE
        strokeWidth = 10000f


    }


    fun diameter():Float {
        // calculates distance of the view and creates the logic for line width
        val chosenDiameter: Float
        val viewWidth: Float = width.toFloat()
        val viewHeight: Float = height.toFloat()
        val diameterX: Float = viewWidth / colCount.toFloat()
        val diameterY: Float = viewHeight / rowCount.toFloat()

        chosenDiameter = if (diameterX < diameterY) {
            diameterX
        } else {
            diameterY
        }

        return chosenDiameter
    }

    private val myGestureDetector = GestureDetector(context, myGestureListener())

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        return myGestureDetector.onTouchEvent(ev) || super.onTouchEvent(ev)
    }


    inner class myGestureListener: GestureDetector.SimpleOnGestureListener() {
        override fun onDown(ev: MotionEvent): Boolean {
            return true
        }
        override fun onSingleTapUp(ev: MotionEvent): Boolean {
            //gets back the cords from the pointer
            touch(diameter(),ev.x,ev.y)
            return true
        }
    }



    fun touch(chosenDiameter:Float,x:Float,y:Float){
        // changes the cords into a grid just like logic and boxes one for the game to get back cords
        val xGrided: Int = ((x + (chosenDiameter*2)-200)/chosenDiameter).toInt()
        val yGrided: Float = kotlin.math.ceil(((y - chosenDiameter)+70) / (chosenDiameter)*2)
        val Y :Int= yGrided.roundToInt()
        //makes sure u cant draw a line thats arleady drawn
        try {
            Game.lines[xGrided, Y].drawLine()
        }catch(e:IllegalArgumentException){

        }
        // updates the game view
        invalidate()

    }



    override fun onDraw(canvas: Canvas) {
        // simple score counters
        var player1:Int = 0
        var player2:Int = 0



        val chosenDiameter: Float=diameter()// calculates distance between lines

        for (col in 0 until colCount) {
            for (row in 0 until rowCount) {
                // creates cords for the distance between lines
                val cx = chosenDiameter * col
                val cy = chosenDiameter * row



                if(col!=colCount-1){
                    if(Game.lines[col, row*2].isDrawn){
                        //draws vertical lines
                        canvas.drawLine(cx+15,cy+15,cx+chosenDiameter+15,cy+15, PaintLine1)
                    }else{
                        // if line is drawn draw it with a different colour
                        canvas.drawLine(cx+15,cy+15,cx+chosenDiameter+15,cy+15, PaintLine)
                    }

                }
                if(row!=rowCount-1){
                    //draws horizontal lines
                    if(Game.lines[col, row*2+1].isDrawn){
                        // if line is drawn draw it with a different colour
                        canvas.drawLine(cx+15,cy+15,cx+15,cy+chosenDiameter+15, PaintLine1)
                    } else{
                        canvas.drawLine(cx+15,cy+15,cx+15,cy+chosenDiameter+15, PaintLine)
                    }

                }
                canvas.drawPoint(cx+15, cy+15,  mNoPlayerPaint)

                if(Game.boxes[col,row].owningPlayer!=null){
                    //draws the boxes once they are completed
                    if (Game.boxes[col,row].owningPlayer==Game.players[0]){
                        canvas.drawPoint(cx+70,cy+71,box)
                        player1+=1
                    }else if (Game.boxes[col,row].owningPlayer==Game.players[1]){
                        canvas.drawPoint(cx+70,cy+71,box1)
                        player2+=1
                    }

                }
                if (player1+player2==49){// once it reaches 49 ticked boxes game ends and displays score
                    canvas.drawColor(Color.WHITE)
                    canvas.drawText("Player1:"+player1.toString(),100f,300f,text)
                    canvas.drawText("Player2:"+player2.toString(),100f,700f,text)

                }

            }
        }





    }
}