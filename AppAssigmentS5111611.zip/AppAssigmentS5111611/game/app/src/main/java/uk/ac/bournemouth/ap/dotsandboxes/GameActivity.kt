package uk.ac.bournemouth.ap.dotsandboxes

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.view.MotionEvent
import android.widget.Button
import org.example.student.dotsboxgame.StudentDotsBoxGame
import uk.ac.bournemouth.ap.dotsandboxeslib.Player

class GameActivity : AppCompatActivity() {


    private lateinit var buttonGoToGame: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)



        buttonGoToGame = findViewById(R.id.restart)

//        Created a listener to allow the application to capture when a user clicks.
        buttonGoToGame.setOnClickListener {

            finish()



        }
    }
}
