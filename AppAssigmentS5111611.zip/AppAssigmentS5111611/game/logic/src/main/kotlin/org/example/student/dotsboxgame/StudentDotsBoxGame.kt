package org.example.student.dotsboxgame

import uk.ac.bournemouth.ap.dotsandboxeslib.*
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.Matrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.MutableMatrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.MutableSparseMatrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.SparseMatrix


class StudentDotsBoxGame(width: Int, height: Int, player: List<Player> = listOf(HumanPlayer(), HumanPlayer())) :AbstractDotsAndBoxesGame() {

    var score:Unit? = null
    override val players: List<Player> = player.toList()
    // ("You will need to get players from your constructor")

    override var currentPlayer: Player = player[0]
    // get()= ("Determine the current player, like keeping the index into the players list")

    override val boxes: Matrix<StudentBox> = MutableMatrix(width, height, ::StudentBox)
    //("Create a matrix initialized with your own box type")

    override val lines: SparseMatrix<StudentLine> =
        MutableSparseMatrix((width + 1), (height * 2 + 1), ::StudentLine) { x, y ->
            y % 2 == 1 || x < width
        }



    override var isFinished: Boolean = false
//        get() = ("Provide this getter. Note you can make it a var to do so")

    override fun playComputerTurns() {
        var current = currentPlayer
        while (current is ComputerPlayer && !isFinished) {
            current.makeMove(this)
            current = currentPlayer
        }
    }

    /**
     * This is an inner class as it needs to refer to the game to be able to look up the correct
     * lines and boxes. Alternatively you can have a game property that does the same thing without
     * it being an inner class.
     */
    inner class StudentLine(lineX: Int, lineY: Int) : AbstractLine(lineX, lineY) {

        override var isDrawn: Boolean = false


        private fun getAdjBoxes(): Pair<StudentBox?, StudentBox?> {
            val boxCord: Pair<StudentBox?, StudentBox?>

            if (lineY % 2 == 0) {//horizontal line
                boxCord = when (lineY) {
                    0                   -> Pair(null, boxes[lineX, lineY / 2])
                    lines.maxHeight - 1 -> Pair(boxes[lineX, (lineY / 2) - 1], null)
                    else                -> Pair(
                        boxes[lineX, (lineY / 2) - 1],
                        boxes[lineX, lineY / 2]
                                               )
                }

            } else {//vertical line
                boxCord = when (lineX) {
                    0                  -> Pair(boxes[lineX, (lineY - 1) / 2], null)
                    lines.maxWidth - 1 -> Pair(null, boxes[lineX - 1, (lineY - 1) / 2])
                    else               -> Pair(
                        boxes[lineX, (lineY - 1) / 2],
                        boxes[lineX - 1, (lineY - 1) / 2]
                                              )

                }

            }
            return boxCord// gets back pair of boxes cords
        }

        override val adjacentBoxes: Pair<StudentBox?, StudentBox?>
            get() = getAdjBoxes()


        override fun drawLine() {

            //main logic of the game creates change the line to draw and checks for ticked boxes
            if (isDrawn) throw IllegalArgumentException("Line Already Drawn")

            isDrawn = true

            val (box1, box2) = adjacentBoxes
            var boxesComplete = false
            if (box1 != null) {
                val boxComplete = box1.boundingLines.all { it.isDrawn }
                if (boxComplete) {
                    boxesComplete=true
                    if (box1.owningPlayer == null) {
                        box1.owningPlayer = currentPlayer
                    }
                }
            }
            if (box2 != null) {
                val boxComplete = box2.boundingLines.all { it.isDrawn }
                if (boxComplete) {
                    boxesComplete=true
                    if (box2.owningPlayer == null) {
                        box2.owningPlayer = currentPlayer
                    }
                }
            }
            if (boxesComplete){
                isFinished=lines.all{it.isDrawn}
                if(isFinished){
                    val scores = getScores().mapIndexed{i,s-> players[i] to s }
                    score = fireGameOver(scores)



                }
            }
            else{
                // changes current player only if they havent completed a box last turn
                if (currentPlayer == players[0]) {
                    currentPlayer = players[1]

                } else if (currentPlayer == players[1]) {
                    currentPlayer = players[0]
                }
                // plays computer turn if the current player is a computer
                playComputerTurns()


            }
            //notifies the game of a change
            fireGameChange()





        }
    }


    inner class StudentBox(boxX: Int, boxY: Int) : AbstractBox(boxX, boxY) {

        override var owningPlayer: Player? = null

        override val boundingLines: Iterable<DotsAndBoxesGame.Line>
            get() = listOf(
                lines[boxX, boxY * 2],     // top line
                lines[boxX, boxY * 2 + 1],   // left
                lines[boxX, boxY * 2 + 2],    // bottom
                lines[boxX + 1, boxY * 2 + 1])//getting the right line
    }
}
class Computer:ComputerPlayer(){
    //make the computer make a move
    override fun makeMove(game: DotsAndBoxesGame) {


        var turn = false
        var x =  (0..6).random()
        var y =  (0..14).random()
        //picks a random line and draws that line in the game logic
        for(line in game.lines){
            if (!line.isDrawn && !turn){
                if(line.lineX == x && line.lineY==y){
                    line.drawLine()
                    turn=true
                }
            }

        }


    }

}





