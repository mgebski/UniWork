Implemented:
computer player which picks random numbers
human player
restart game
display score 
basic functionality of the game
game display