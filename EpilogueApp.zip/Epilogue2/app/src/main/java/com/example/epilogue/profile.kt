package com.example.epilogue
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.login.*
import kotlinx.android.synthetic.main.profile.*
import kotlinx.android.synthetic.main.profile.Email
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.internal.wait
import org.jetbrains.anko.email
import java.io.IOException
import java.net.URL

class profile: AppCompatActivity() {
    private lateinit var back:Button
    private lateinit var confirmChange:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile)
        var emailLogin = intent.getStringExtra("email")
        Log.d("email",emailLogin)

        var result = URL("http://10.0.2.2:3000/user/read?apiKey=12345&email="+emailLogin)
        val payload = "test payload"
        val client = OkHttpClient()
        val requestBody = payload.toRequestBody()
        val request = Request.Builder().method("POST",requestBody).url(result).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                var newBody= body.toString()
                Log.d("userinfo", body.toString())
                var strarray : List<String> = newBody.split(",")
                var oldfirstname = strarray[1].replaceRange(0,12,"").replace("\"", "")
                var oldlastname = strarray[2].replaceRange(0,11,"").replace("\"", "")
                var oldEmail = strarray[3].replaceRange(0,8,"").replace("\"", "")


                runOnUiThread(){
                    Firstname.hint = oldfirstname
                    Lastname.hint = oldlastname
                    Email.hint = oldEmail
                }
            }
            override fun onFailure(call: Call, e: IOException) {
            }
        })

        confirmChange= findViewById(R.id.confirm)

        confirmChange.setOnClickListener{
            var result = URL("http://10.0.2.2:3000/user/read?apiKey=12345&email="+emailLogin)
            val payload = "test payload"
            val client = OkHttpClient()
            val requestBody = payload.toRequestBody()
            val request = Request.Builder().method("POST",requestBody).url(result).build()

            client.newCall(request).enqueue(object : Callback {
                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string()

                    //data proccessing from the api
                    var newBody= body.toString()
                    var strarray : List<String> = newBody.split(",")


                    var userid = strarray[0].replaceRange(0,8,"").replace("\"", "")

                    var oldfirstname = strarray[1].replaceRange(0,12,"").replace("\"", "")
                    var oldlastname = strarray[2].replaceRange(0,11,"").replace("\"", "")
                    var oldEmail = strarray[3].replaceRange(0,8,"").replace("\"", "")

                    var firstname = Firstname.text.toString()
                    var lastname = Lastname.text.toString()
                    var Email = Email.text.toString()
                    var pass = NewPass.text.toString()
                    var connewpass = ConfirmNewPass.text.toString()

                    var newfirstname:String
                    var newlastname:String
                    var newEmail:String
                    var newpass:String



                    if (pass == connewpass&&pass!="") {
                        newpass = pass
                        if (firstname != oldfirstname) {
                            newfirstname = firstname

                        } else {
                            newfirstname = oldfirstname
                        }
                        if (lastname != oldlastname) {
                            newlastname = lastname
                        } else {
                            newlastname = oldlastname
                        }
                        if (Email != oldEmail) {
                            newEmail = Email
                        } else {
                            newEmail = oldEmail
                        }
                        fun changeInfo(userid:String,firstname:String,lastname:String,email:String,password:String){

                            var result = URL("http://10.0.2.2:3000/user/update?apiKey=12345&userID="+ userid+"&firstName="+ firstname+"&lastName="+lastname+"&password="+ password+"&email="+email+"&adverts=true")
                            val payload = "test payload"
                            val client = OkHttpClient()
                            val requestBody = payload.toRequestBody()
                            val request = Request.Builder().method("POST",requestBody).url(result).build()

                            client.newCall(request).enqueue(object : Callback {
                                override fun onResponse(call: Call, response: Response) {

                                }

                                override fun onFailure(call: Call, e: IOException) {
                                        Log.d("got it","didnt make it")
                                }
                            })

                        }
                        changeInfo(userid,newfirstname,newlastname,newEmail,newpass)
                        Log.d("f","made it")
                    } else{
                        changes.text= "please confirm your password"
                    }

                }

                override fun onFailure(call: Call, e: IOException) {
                    changes.text = "Changes Failed to update"
                }

        })

        }

        back = findViewById(R.id.back)

        back.setOnClickListener {




            finish()
        }

    }
}

