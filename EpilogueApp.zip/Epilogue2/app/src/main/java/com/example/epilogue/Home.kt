package com.example.epilogue

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.profile.*
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URL


class Home : AppCompatActivity() {
    private lateinit var search: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        search = findViewById(R.id.SearchBtn)
        val ss = intent.getStringExtra("email")
        val intent = Intent(this, MediaPage::class.java)
        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
        var mediaID=0
        val languages = resources.getStringArray(R.array.media)

        val spinner = findViewById<Spinner>(R.id.DropDown)

        if (spinner != null) {
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, languages)
            spinner.adapter = adapter

            spinner.onItemSelectedListener =  object :
            AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View, position: Int, id: Long) {

                      var picked =  languages[position]
                      search.setOnClickListener {
                          var searchbar = SearchBar.text.toString()

                          var result= URL("http://10.0.2.2:3000/anime/read/all?apiKey=12345")
                          if(picked=="anime"){
                              result = URL("http://10.0.2.2:3000/anime/read/all?apiKey=12345")
                              mediaID=1
                          }else if(picked=="books"){
                              result = URL("http://10.0.2.2:3000/books/read/all?apiKey=12345")
                              mediaID=2
                          }else if(picked=="movies"){
                              result = URL("http://10.0.2.2:3000/movies/read/all?apiKey=12345")
                              mediaID=3
                          }else if(picked=="shows"){
                              result = URL("http://10.0.2.2:3000/shows/read/all?apiKey=12345")
                              mediaID=4
                          }

                          val payload = "test payload"
                          val client = OkHttpClient()
                          val requestBody = payload.toRequestBody()
                          val request = Request.Builder().method("POST",requestBody).url(result).build()
                          var list:List<String> = ArrayList()
                          client.newCall(request).enqueue(object : Callback {
                              override fun onResponse(call: Call, response: Response) {
                                  val body = response.body?.string()
                                  val newBody = body.toString()
                                  Log.d("book",newBody)
                                  var s : List<String> = newBody.split("},{")



                                  var i = 0
                                  for (x in s){
                                      var strarray:List<String> = s[i].split(",")

                                      var id= strarray[0].replaceRange(0,7,"").replace("\"", "")
                                      id=id.replace(":","")
                                      Log.d("id",id)
                                      var name= strarray[1].replaceRange(0,7,"").replace("\"", "")




                                      var listofMedia:Array<String> = arrayOf(id,name)
                                      if(name.contains(searchbar,ignoreCase = true)){
                                          list = list + listofMedia
                                      }

                                      i+=1

                                  }

                                  var listView: ListView = findViewById<ListView>(R.id.SearchResult)
                                  var listItems= arrayListOf("")
                                  var listItems3= arrayListOf("")


                                  for (i in 0 until list.size) {
                                      if (i % 2 == 0) {
                                          val recipe = list[i]
                                          listItems3.add(recipe)

                                      }else{
                                          val recipe = list[i]
                                          listItems.add(recipe)
                                      }
                                  }

                                  var names = listItems.toString().replace("[,","").replace("]","")
                                  var ids = listItems3.toString().replace("[,","").replace("]","")
                                  var h =names.split(",")
                                  var j =ids.split(",")
                                  Log.d("j",j.toString())
                                  Log.d("h",h.toString())
                                  runOnUiThread(){

                                      val adapter = ArrayAdapter(this@Home, R.layout.row , h)
                                      listView.adapter = adapter

                                      listView.setOnItemClickListener { _, _, position, _ ->

                                          val selectedMedia = j[position]
                                          Log.d("d",selectedMedia)
                                          intent.putExtra("item",selectedMedia)
                                          intent.putExtra("name",mediaID)
                                          intent.putExtra("email",ss)
                                          startActivity(intent)
                                      }
                                  }
                              }
                              override fun onFailure(call: Call, e: IOException) {
                              }

                          })
                    }

                }
            }
        }
        }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        when (item.itemId) {

            R.id.action_Profile -> {
                val ss:String? = intent.getStringExtra("email")
                val intent = Intent(this,profile::class.java)
                intent.putExtra("email",ss)
                startActivity(intent)

            }
            R.id.action_logout -> {
                finish()

            }


        }
        return super.onOptionsItemSelected(item)
    }

}