package com.example.epilogue
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.media.*
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URL

class MediaPage: AppCompatActivity() {
    private lateinit var back:Button
    private lateinit var p:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.media)
        back = findViewById(R.id.back2)
        p = findViewById(R.id.leaveReview)
        var _id = intent.getStringExtra("item").replace(" ","")
        Log.d("pr",_id)
        var mediaid = intent.getIntExtra("name",0 )//data from previous actvity which containt what media type the user has choosen to search for
        val ss = intent.getStringExtra("email")



        lateinit var result:URL
        lateinit var reviews:URL
        //creating urls depending on choosen media
        if(mediaid==1){
            result = URL("http://10.0.2.2:3000/anime/read/?apiKey=12345&animeID="+_id)
            reviews= URL("http://10.0.2.2:3000/anime/review/read/?apiKey=12345&animeID="+_id)
        }else if(mediaid==2){
            result = URL("http://10.0.2.2:3000/books/read/?apiKey=12345&bookID="+_id)
            reviews= URL("http://10.0.2.2:3000/books/review/read/?apiKey=12345&bookID="+_id)
        }else if(mediaid==3){
            result = URL("http://10.0.2.2:3000/movies/read/all?apiKey=12345&movieID="+_id)
            reviews= URL("http://10.0.2.2:3000/movies/review/read/?apiKey=12345&movieID="+_id)
        }else if(mediaid==4){
            result = URL("http://10.0.2.2:3000/shows/read/all?apiKey=12345&showID="+_id)
            reviews= URL("http://10.0.2.2:3000/shows/review/read/?apiKey=12345&showID="+_id)
        }

        Log.d("",reviews.toString())
        val payload = "test payload"
        val client = OkHttpClient()
        val c = OkHttpClient()
        val requestBody = payload.toRequestBody()
        val request = Request.Builder().method("POST",requestBody).url(result).build()
        val req = Request.Builder().method("POST", requestBody).url(reviews).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {

            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                val newBody = body.toString()


                var strarray: List<String> = newBody.split(",")


                var name = strarray[1].replaceRange(0, 7, "").replace("\"", "")
                var author = strarray[2].replaceRange(0, 9, "").replace("\"", "")
                var genre = strarray[4].replaceRange(0, 8, "").replace("\"", "")
                var desc = strarray[3].replaceRange(0, 14, "").replace("\"", "")
                genre = genre.replace("}]", "")
                runOnUiThread {
                    Title.text = name
                    Author.text = author
                    type.text = genre
                    Desc.text = desc
                }

            }
            })
        c.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {

            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                val newBody = body.toString()
                var s: List<String> = newBody.split("},{")
                Log.d("2",s.toString())
                var list:List<String> = ArrayList()
                var i = 0//counter
                var star:Float= 0.0F
                if(newBody!="[]"){
                    for (x in s) {
                        var strarray: List<String> = s[i].split(",")
                        //taking out data from the result and putting it into its own variables
                        var reviewer = strarray[2].replaceRange(0, 9, "").replace("\"", "")
                        reviewer=reviewer.replace(":","")
                        var stars = strarray[3].replaceRange(0, 6, "").replace("\"", "")
                        stars=stars.replace(":","")
                        if(stars=="null")
                        {
                            stars= "0"
                        }
                        var cont = strarray[4].replaceRange(0, 8, "").replace("\"", "")
                        cont=cont.replace(":","")
                        cont = cont.replace("}]", "")
                        star+=stars.toFloat()
                        var listofMedia: String = "Reviever:" + reviewer + "\n Rating:" + stars + "\nReview:" + cont
                        list=list+listofMedia
                        i+=1
                    }
                    star /= i
                    var listView: ListView = findViewById(R.id.ShowReviews)

                    runOnUiThread() {

                        val adapter = ArrayAdapter(this@MediaPage, R.layout.row, list)
                        listView.adapter = adapter
                        ratingbar.rating = star

                    }

                }

            }
        })


        back.setOnClickListener {
            finish()
        }
        val intent = Intent(this, review::class.java)
        intent.putExtra("id",_id)
        intent.putExtra("mediaid",mediaid)


        intent.putExtra("email",ss)

        p.setOnClickListener {
            startActivity(intent)


            finish()


        }

    }





}