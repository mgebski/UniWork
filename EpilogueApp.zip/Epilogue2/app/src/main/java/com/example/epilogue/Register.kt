package com.example.epilogue

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.register.*
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import org.jetbrains.anko.custom.async
import java.io.IOException
import java.net.URL
import kotlin.Error
//register page
class Register : AppCompatActivity() {
    private lateinit var back:Button
    private lateinit var register: Button

    //create registed page
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)
        register= findViewById(R.id.ConReg)
        back = findViewById(R.id.backRegister)
        back.setOnClickListener {
            finish()
        }
        register.setOnClickListener {
            //on button press take out data from those fields from the ui
            var email= Email.text.toString()
            var password= Pass.text.toString()
            var conPass= ConPass.text.toString()
            var firstname = FirstName.text.toString()
            var lastname =  LastName.text.toString()

            //check if inputed passwords are the same
            if(password==conPass){
                if(email!=""&&password!=""&&firstname!=""&&lastname!=""){
                    fun prefRegister(email:String,password:String,firstname:String,lastname:String){
                        //create the api post url
                        var result = URL("http://10.0.2.2:3000/user/create?apiKey=12345&firstName="+firstname+"&lastName="+lastname+"&email="+email+"&password="+password+"&adverts=true")
                        val payload = "test payload"
                        val client = OkHttpClient()
                        val requestBody = payload.toRequestBody()
                        val request = Request.Builder().method("POST",requestBody).url(result).build()
                        //fire api call
                        client.newCall(request).enqueue(object : Callback {
                            override fun onResponse(call: Call, response: Response) {
                                val body = response.body?.string()
                                Log.d("response", body.toString())
                            }

                            override fun onFailure(call: Call, e: IOException) {
                                Log.d("Failed", result.toString())
                            }
                        })
                    }
                    prefRegister(email,password,firstname,lastname)
                    //push data into the database
                    finish()
                }else{
                    Error.text = "Fields can not be left Blank"
                }

            }else{
                Error.text = "Passwords do not match"
            }






        }



    }
}