package com.example.epilogue

import android.content.Intent

import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.GsonBuilder
import kotlinx.android.synthetic.main.login.*

import okhttp3.*

import java.io.IOException

import java.net.URL
import okhttp3.RequestBody.Companion.toRequestBody
import org.jetbrains.anko.custom.async
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.doAsyncResult
import java.util.concurrent.ArrayBlockingQueue
//login activity

class MainActivity : AppCompatActivity() {

    //button variables
    private lateinit var loginBtn: Button
    private lateinit var register: Button


    //creating the view
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        loginBtn = findViewById(R.id.login)
        register = findViewById(R.id.reg)

        //login button listener
        loginBtn.setOnClickListener {
            var email = EmailLogin.text.toString()
            var password = Password.text.toString()




            //check if email is not blank
            if(email!=""){
                var result = URL("http://10.0.2.2:3000/user/verifyPass?apiKey=12345&email="+email+"&password="+password)
                val payload = "test payload"
                val client = OkHttpClient()
                val requestBody = payload.toRequestBody()
                val request = Request.Builder().method("POST",requestBody).url(result).build()


                //creating a intent for a new activity which is home screen
                val intent = Intent(this, Home::class.java)

                intent.putExtra("email",email)
                //checking with the api if an account exists with the inputed data
                client.newCall(request).enqueue(object : Callback{
                    override fun onResponse(call: Call, response: Response) {
                        runOnUiThread{
                            val body = response.body?.string()
                            if(body.toString()=="true") {
                                startActivity(intent)
                                Log.d("response", body.toString())
                            }
                            }




                    }

                    override fun onFailure(call: Call, e: IOException) {
                        Log.d("Failed", result.toString())
                    }
                })




                } else{
                errorLogin.text = "Email can not be blank"
            }


        }




            // register button
        register.setOnClickListener {
            val intent = Intent(this, Register::class.java)

            startActivity(intent)


        }
    }

}

