package com.example.epilogue

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.leavereview.*
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URL
//leave a review activity
class review : AppCompatActivity() {
    private lateinit var back: Button
    private lateinit var submit: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leavereview)
        back = findViewById(R.id.backReview)
        submit = findViewById(R.id.submitReview)
        val ss = intent.getStringExtra("email")
        var id = intent.getStringExtra("id")
        var result= URL("http://10.0.2.2:3000/user/read?apiKey=12345&email="+ss)
        val payload = "test payload"
        val client = OkHttpClient()
        val requestBody = payload.toRequestBody()
        val request = Request.Builder().method("POST",requestBody).url(result).build()
        lateinit var res:URL
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {

            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                var newBody= body.toString()

                var strarray : List<String> = newBody.split(",")

                var userid = strarray[0].replaceRange(0,8,"").replace("\"", "")

                submit.setOnClickListener{

                    var mediaid = intent.getIntExtra("mediaid",0 )//chosen media
                    Log.d("",mediaid.toString())
                    var rating = rating.rating
                    var content = reviewContent.text.toString()

                    //create url for api depending on what media the user is reviewing
                    if(mediaid==1){
                        res = URL("http://10.0.2.2:3000/anime/review?apiKey=12345&animeID="+id+"&reviewer="+userid+"&stars="+rating +"&content="+content)
                    }else if(mediaid==2){
                        res = URL("http://10.0.2.2:3000/books/review?apiKey=12345&bookID="+id+"&reviewer="+userid+"&stars="+rating +"&content="+content)
                    }else if(mediaid==3){
                        res = URL("http://10.0.2.2:3000/movies/review?apiKey=12345&movieID="+id+"&reviewer="+userid+"&stars="+rating +"&content="+content)
                    }else if(mediaid==4){
                        res = URL("http://10.0.2.2:3000/shows/review?apiKey=12345&showID="+id+"&reviewer="+userid+"&stars="+rating +"&content="+content)
                    }

                    val payload = "test payload"
                    val c = OkHttpClient()
                    val requestBody = payload.toRequestBody()
                    val req = Request.Builder().method("POST",requestBody).url(res).build()
                    c.newCall(req).enqueue(object : Callback {
                        override fun onFailure(call: Call, e: IOException) {

                        }

                        override fun onResponse(call: Call, response: Response) {

                            finish()
                        }


                    })

                }
            }


        })

        back.setOnClickListener {
            finish()
        }
    }
}